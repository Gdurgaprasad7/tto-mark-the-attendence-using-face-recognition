import pickle
from django.shortcuts import render
from django.conf import settings
from django.contrib import messages
import os
from .models import Attendance, UserProfile  # Adjust based on your app's models



def student_register(request):
    if request.method == 'POST':
        try:
            # Extract form data
            name = request.POST.get('name')
            loginid = request.POST.get('loginid')
            mobile = request.POST.get('mobile')
            password = request.POST.get('password')
            images = request.FILES.getlist('images')

            # Validate data (basic example)
            if not all([name, loginid, mobile, password]):
                messages.error(request, 'All fields are required.')
                return render(request, 'index.html')

            if len(images) != 50:
                messages.error(request, 'Exactly 50 images are required.')
                return render(request, 'index.html')

            # Save user data to database
            user = UserProfile.objects.create(
                name=name,
                loginid=loginid,
                mobile=mobile,
                password=password  # Note: In production, hash the password
            )

            # Create directory for images
            image_dir = os.path.join(settings.MEDIA_ROOT, loginid)
            os.makedirs(image_dir, exist_ok=True)

            # Save each image
            for index, image in enumerate(images, 1):
                image_path = os.path.join(image_dir, f'image_{index}.jpg')
                with open(image_path, 'wb') as f:
                    for chunk in image.chunks():
                        f.write(chunk)

            messages.success(request, 'Registration successful!')
            return render(request, 'index.html')

        except Exception as e:
            messages.error(request, f'An error occurred: {str(e)}')
            return render(request, 'index.html')

    # If not POST, render the form
    return render(request, 'index.html')


import os
import logging
import numpy as np
import cv2
import pickle
from datetime import datetime
from django.http import StreamingHttpResponse, JsonResponse
from django.conf import settings
from django.contrib.auth.decorators import login_required
from keras.models import load_model
import face_recognition
from .models import Attendance

logger = logging.getLogger(__name__)

# Global variables
live_cap = None
model = None
encoder = None

def init_live_capture():
    global live_cap
    if live_cap is None or not live_cap.isOpened():
        live_cap = cv2.VideoCapture(0)
        if not live_cap.isOpened():
            logger.error("Error: Could not open live capture source.")
            live_cap = None

def load_model_and_encoder():
    global model, encoder
    if model is None or encoder is None:
        model_path = os.path.join(settings.BASE_DIR, 'models', 'softmax_model.h5')
        encoder_path = os.path.join(settings.BASE_DIR, 'models', 'label_encoder.pkl')

        if not os.path.exists(model_path) or not os.path.exists(encoder_path):
            logger.error("Model or encoder file missing.")
            return False

        model = load_model(model_path)
        with open(encoder_path, 'rb') as f:
            encoder = pickle.load(f)
    return True

def realtime(request):
    def generate_frames():
        global live_cap, model, encoder
        init_live_capture()

        if not load_model_and_encoder():
            yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + b'' + b'\r\n')
            return

        while True:
            success, frame = live_cap.read()
            if not success:
                break

            frame = cv2.resize(frame, (640, 480))
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            face_locations = face_recognition.face_locations(rgb_frame)
            face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

            for (top, right, bottom, left), face_embedding in zip(face_locations, face_encodings):
                probabilities = model.predict(np.array([face_embedding]), verbose=0)
                prediction = probabilities[0].argmax()
                confidence = float(probabilities[0][prediction])

                if confidence > 0.6:
                    label = encoder.inverse_transform([prediction])[0]
                else:
                    label = "Unknown"

                color = (0, 255, 0) if label != "Unknown" else (0, 0, 255)

                cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
                cv2.putText(frame, f'{label} ({confidence:.2f})', (left, top - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)

            _, buffer = cv2.imencode('.jpg', frame)
            yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')

        live_cap.release()

    return StreamingHttpResponse(generate_frames(), content_type='multipart/x-mixed-replace; boundary=frame')

import base64
from django.http import JsonResponse
from datetime import datetime
import numpy as np
import cv2
import face_recognition
from .models import Attendance
from django.conf import settings
import logging

logger = logging.getLogger(__name__)

def validate_face(request):
    if request.method != 'POST':
        return JsonResponse({"valid": False, "message": "Invalid request method."}, status=400)

    try:
        if not load_model_and_encoder():
            return JsonResponse({"valid": False, "message": "Server configuration error."}, status=500)

        import json
        data = json.loads(request.body)
        image_data = data.get("image")

        if not image_data:
            return JsonResponse({"valid": False, "message": "No image data provided."}, status=400)

        header, encoded = image_data.split(',', 1)
        img_bytes = base64.b64decode(encoded)
        nparr = np.frombuffer(img_bytes, np.uint8)
        frame = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        faces = face_recognition.face_locations(frame_rgb)
        logger.info(f"Detected {len(faces)} face(s).")

        if not faces:
            return JsonResponse({
                "valid": False,
                "message": "No face detected.",
                "redirect": True
            })

        face_location = faces[0]
        embeddings = face_recognition.face_encodings(frame_rgb, [face_location])
        if not embeddings:
            return JsonResponse({
                "valid": False,
                "message": "Unable to process face.",
                "redirect": True
            })

        face_embedding = embeddings[0]
        probabilities = model.predict(np.array([face_embedding]), verbose=0)
        prediction = probabilities[0].argmax()
        confidence = float(probabilities[0][prediction])
        student_id = encoder.inverse_transform([prediction])[0]
        confidence_threshold = getattr(settings, 'FACE_CONFIDENCE_THRESHOLD', 0.)


        if confidence >= confidence_threshold:
            timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            Attendance.objects.create(timestamp=timestamp, student_id=student_id, classification='Presented')
            return JsonResponse({
                "valid": True,
                "message": "✅ Face verified",
                "student_id": student_id,
                "confidence": confidence,
                "redirect": True
            })

        return JsonResponse({
            "valid": False,
            "message": f"Face not recognized (confidence: {confidence:.2f}).",
            "redirect": True
        })

    except Exception as e:
        logger.error("Error validating face", exc_info=e)
        return JsonResponse({"valid": False, "message": "Internal server error."}, status=500)


    except Exception as e:
        logger.exception("Error during face validation")
        return JsonResponse({
            "valid": False,
            "message": "An error occurred during face validation.",
            "redirect": False
        }, status=500)


